#ifndef R_SOFIA_FACADE_H
#define R_SOFIA_FACADE_H

#include <Rcpp.h>
#include "sf-data-set.h"
#include "sofia_cmd.h"

class RSofiaFacade {

  public:
    RSofiaFacade();
    static std::vector<float> train(
          const SfDataSet& training_data 
        , const long int random_seed
        , const double lambda
        , const long int iterations
        , const string& learner_type
        , const long int iterations
        , const string& eta_type
        , const string& loop_type 
	, const double rank_step_probability
        , const double passive_aggressive_c
        , const double passive_aggressive_lambda = 0
        , const double perceptron_margin_size = 1.0
        , const bool training_objective 
        , const int dimensionality
        , const int hash_mask_bits
        , const bool no_bias_term
    );

    //extractors

};

#endif
